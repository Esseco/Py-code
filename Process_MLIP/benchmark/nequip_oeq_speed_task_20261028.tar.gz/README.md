# NequIP OAM OpenEquivariance full speed batch

Prepared for four separate V100 jobs: OAM-S/M/L/XL 0.2, one GPU job per model, each over
LCO_84/189/378/756 and NVP_120/240/480/720. Each job compiles its weight to TorchScript with
`enable_OpenEquivariance`, then runs full-cell ASE LBFGS (`fmax=0.1`, 2000 max steps,
`maxstep=0.2`) and ASE NVT (`800 K`, `2 fs`, 1000 steps). Every job has a separate results
root and unique compiled model, avoiding lock/output collisions. The jobs reuse the validated
OpenEquivariance extension cache from the path-fix validation directory.

The scripts and package are prepared locally only. Do not upload or submit until the separate
V100 OpenEquivariance validation has printed `OPEN_EQUIVARIANCE_V100_VALIDATED`.