#!/bin/bash
#SBATCH --job-name=nep89_native
#SBATCH --partition=v100m3
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=6
#SBATCH --gres=gpu:1
#SBATCH --mem=64G
#SBATCH --time=48:00:00
#SBATCH --chdir=/data/home/lichaoyue/26-7-AEA/MLIP_nep89_native_speed_20261028
#SBATCH --output=/data/home/lichaoyue/26-7-AEA/MLIP_nep89_native_speed_20261028/nep89_native-%j.out
#SBATCH --error=/data/home/lichaoyue/26-7-AEA/MLIP_nep89_native_speed_20261028/nep89_native-%j.err
set -euo pipefail
export OMP_NUM_THREADS=6
export MKL_NUM_THREADS=6
export PYTHONPATH=/data/home/lichaoyue/Process_code
export MPLBACKEND=Agg
ulimit -c 0
module load gpumd/5.9.1-cuda129
exec /data/home/lichaoyue/.venvs/nep-speed/bin/python -u -m Process_MLIP.benchmark speed /data/home/lichaoyue/26-7-AEA/MLIP_nep89_native_speed_20261028/config.yaml --model nep89_native