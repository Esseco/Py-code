# NEP89 native-MD speed rerun

This task reruns the complete LCO/NVP speed benchmark after correcting the MD timing path.
The prior ASE-GPUNEP MD adapter launched GPUMD and exchanged files once per force request;
this task uses one continuous GPUMD native `run 1000` for each MD structure. Full-cell
ASE LBFGS relaxation remains unchanged and therefore still includes GPUNEP process/I/O cost.

## Inputs and outputs

- Eight server structures: LCO_84/189/378/756 and NVP_120/240/480/720 under the existing
  `MLIP_speed_pilot_20261027/structures` directory.
- Existing NEP89 potential and GPUMD 5.9.1 executable; no model download or installation.
- Output root: `results/speed/nep89_native`; previous benchmark results are not reused.
- Relaxation: full atomic and cell LBFGS, fmax 0.1 eV/A, max 2000 steps, maxstep 0.2 A.
- MD: NVT 800 K, 2 fs, 1000 steps (2 ps), seed 42; native GPUMD NHC chain length 4.
- Native MD reports GPUMD's internal integration timer separately from end-to-end stage wall time.

## Remote code overlay

Before submission, install the three files from `overlay/Process_MLIP/benchmark/` into the
same paths in `/data/home/lichaoyue/Process_code`. `config.py` and `runner.py` replace the
clean `53604ee` versions with local versions that add the NEP native-MD option; `config.py`
also preserves the requested ORB compile-by-default setting. `nep_native.py` is a new module.
The benchmark uses the existing Process_code `Process_MLIP.nep_md.run_nep_md()` API.