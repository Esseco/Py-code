#!/bin/bash
#SBATCH --job-name=nequip_s_baseline
#SBATCH --partition=v100m3
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=6
#SBATCH --gres=gpu:1
#SBATCH --mem=64G
#SBATCH --time=48:00:00
#SBATCH --chdir=/data/home/lichaoyue/26-7-AEA/MLIP_nequip_s_baseline_20261028
#SBATCH --output=/data/home/lichaoyue/26-7-AEA/MLIP_nequip_s_baseline_20261028/baseline-%j.out
#SBATCH --error=/data/home/lichaoyue/26-7-AEA/MLIP_nequip_s_baseline_20261028/baseline-%j.err
set -euo pipefail
ulimit -c 0
module load gcc/11.2.0
module load cuda/12.8
export PATH=/data/home/lichaoyue/.conda/envs/nequip/bin:$PATH
export OMP_NUM_THREADS=6 MKL_NUM_THREADS=6 MPLBACKEND=Agg
export PYTHONPATH=/data/home/lichaoyue/Process_code
exec /data/home/lichaoyue/.conda/envs/nequip/bin/python -u -m Process_MLIP.benchmark speed /data/home/lichaoyue/26-7-AEA/MLIP_nequip_s_baseline_20261028/config.yaml --model nequip_oam_s_baseline