#!/bin/bash
#SBATCH --job-name=nequip_oeq_fix
#SBATCH --partition=v100m3
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=6
#SBATCH --gres=gpu:1
#SBATCH --mem=64G
#SBATCH --time=04:00:00
#SBATCH --chdir=/data/home/lichaoyue/26-7-AEA/MLIP_nequip_oeq_pathfix_20261028
#SBATCH --output=/data/home/lichaoyue/26-7-AEA/MLIP_nequip_oeq_pathfix_20261028/nequip_oeq-%j.out
#SBATCH --error=/data/home/lichaoyue/26-7-AEA/MLIP_nequip_oeq_pathfix_20261028/nequip_oeq-%j.err
set -euo pipefail
ulimit -c 0
module load gcc/11.2.0
module load cuda/12.8
export PATH=/data/home/lichaoyue/.conda/envs/nequip/bin:$PATH
export TORCH_EXTENSIONS_DIR=/data/home/lichaoyue/26-7-AEA/MLIP_nequip_oeq_pathfix_20261028/torch_extensions
export MAX_JOBS=6
export OMP_NUM_THREADS=6
export MKL_NUM_THREADS=6
export PYTHONPATH=/data/home/lichaoyue/Process_code
export MPLBACKEND=Agg
work=/data/home/lichaoyue/26-7-AEA/MLIP_nequip_oeq_pathfix_20261028
mkdir -p "$work/compiled" "$TORCH_EXTENSIONS_DIR"
command -v ninja
ninja --version
nequip-compile /data/home/lichaoyue/Process_code/MLIP_model/nequip/NequIP-OAM-S-0.2.nequip.zip "$work/compiled/NequIP-OAM-S-0.2-baseline.nequip.pth" --mode torchscript --device cuda --target ase
nequip-compile /data/home/lichaoyue/Process_code/MLIP_model/nequip/NequIP-OAM-S-0.2.nequip.zip "$work/compiled/NequIP-OAM-S-0.2-oeq-pathfix.nequip.pth" --mode torchscript --device cuda --target ase --modifiers enable_OpenEquivariance
/data/home/lichaoyue/.conda/envs/nequip/bin/python -u /data/home/lichaoyue/26-7-AEA/MLIP_nequip_oeq_check_20261028/validate_oeq.py "$work/compiled/NequIP-OAM-S-0.2-baseline.nequip.pth" "$work/compiled/NequIP-OAM-S-0.2-oeq-pathfix.nequip.pth"