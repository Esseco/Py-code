# NequIP OpenEquivariance V100 retry

The first validation job failed before calculation. Its compile process used an absolute
`nequip-compile` path but did not add the NequIP environment's `bin` directory to `PATH`.
OpenEquivariance falls back to JIT with the installed PyTorch 2.9.0, and its compiler could
not find the already-installed `ninja` executable. This retry adds the environment `bin` to
`PATH`, caps the build at six jobs, and uses a fresh task-local Torch extension cache.

It compiles a fresh unaccelerated TorchScript baseline and an OpenEquivariance version from
the existing official OAM-S 0.2 package, then runs the existing two-structure V100 comparison
for finite energy/forces/stress, speed sampling, and short LBFGS/NVT checks. No package is
installed, and no previous compiled model or result is overwritten. Successful completion
prints `OPEN_EQUIVARIANCE_V100_VALIDATED`.